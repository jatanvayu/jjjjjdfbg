
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.util.JdbcConnection;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       String url;
    
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		String m_username=request.getParameter("username");
		String m_password=request.getParameter("password");
		Connection con = null;
		con = JdbcConnection.getConnection();
		ResultSet rs = null;
		PreparedStatement ps=null;
		
		try {
			PrintWriter out = response.getWriter();
			//out.print("Welcome to login page");
			ps=con.prepareStatement("select * from admin where emailid=?");
			ps.setString(1,m_username);
			rs=ps.executeQuery();
			
			
			while(rs.next())
			{
				Admin admin = new Admin(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				out.print(rs.getString(1)+""+ rs.getString(2)+""+rs.getString(3)+""+rs.getString(4)+""+rs.getString(5));
			if(rs.getString(4).equals("a"))
			{
				url="AdminServlet";
				HttpSession session = request.getSession();
				session.setAttribute("s_admin", admin);
			}
			else
			{
				url="UserServlet";
			}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		RequestDispatcher rd =  request.getRequestDispatcher(url);
		rd.forward(request, response);
		
	}

}
