

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

/**
 * Servlet implementation class ChangePasswordServlet
 */
public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePasswordServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String	url=null;
		LoginDao loginDao = new LoginDaoImpl();
		String m_oldPassword=request.getParameter("OldPassword");
		String m_newPassword=request.getParameter("NewPassword");
		String m_confirmPassword=request.getParameter("ConfrimPassword");
		HttpSession session =request.getSession(false);
		String username = (String)session.getAttribute("u_username");
	boolean a=	loginDao.changePassword(username, m_oldPassword, m_newPassword, m_confirmPassword);
		if(a!=false)
		{
	      url="Customer.jsp";
		}
		else
		{
		  url = "ChangePassword.jsp";
		}
		PrintWriter pw =response.getWriter();
		pw.println("<html>");
		pw.println("Password Changed Sussfully");
		pw.println("</html>");
		RequestDispatcher rd = request.getRequestDispatcher("ChangePassword.jsp");
		rd.include(request, response);
	}

}
