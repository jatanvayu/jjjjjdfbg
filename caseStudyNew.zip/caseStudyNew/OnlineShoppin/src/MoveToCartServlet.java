

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

/**
 * Servlet implementation class MoveToCartServlet
 */
public class MoveToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MoveToCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String product=request.getParameter("value");
		HttpSession session2 =request.getSession(false);
		String username = (String)session2.getAttribute("u_username");
		LoginDao login = new LoginDaoImpl();
		login.MoveToWishCart(product, username);
		login.DeleteFromWishList(product, username);
		RequestDispatcher rd =request.getRequestDispatcher("WishList.jsp");
		rd.forward(request, response);
	}

}
