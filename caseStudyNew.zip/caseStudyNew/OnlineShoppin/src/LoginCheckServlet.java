

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

/**
 * Servlet implementation class LoginCheckServlet
 */
public class LoginCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       String url;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String m_username = request.getParameter("username");
		String m_password = request.getParameter("password");
		
		LoginDao loginDao = new LoginDaoImpl();
		String type=loginDao.validate(m_username, m_password);
		
		if(type != null)
		{
			if(type.equals("a"))
			{
			
				url="Adminjsp.jsp";
				HttpSession session = request.getSession(true);
				session.setAttribute("u_username", m_username);
				session.setAttribute("u_password", m_password);
				RequestDispatcher rd = request.getRequestDispatcher(url);
				rd.forward(request, response);
			}
			else if(type.equals("u"))
			{
				HttpSession session = request.getSession(true);
				session.setAttribute("u_username", m_username);
			   session.setAttribute("u_password", m_password);
				
				url="Customer.jsp";
				RequestDispatcher rd = request.getRequestDispatcher(url);
				rd.forward(request, response);
			}
		}
		else
		{
			out.println("<font color='red'>Invalid Username/ Password </font>"); 
		    url = "Loginjsp.jsp";
		    RequestDispatcher rd = request.getRequestDispatcher(url);
			rd.include(request, response);
		}
		
	}

}
