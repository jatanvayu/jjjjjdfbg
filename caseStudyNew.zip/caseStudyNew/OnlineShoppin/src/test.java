import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.util.JdbcConnection;


public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Connection con =null;
con=JdbcConnection.getConnection();
ResultSet rs = null;
PreparedStatement ps = null;
try {
	ps=con.prepareStatement("select ename from emp where empno=?");
	ps.setInt(1, 7839);
	
	rs=ps.executeQuery();
	while(rs.next())
			{
		System.out.println(rs.getInt(1));
			}
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


	}

}
