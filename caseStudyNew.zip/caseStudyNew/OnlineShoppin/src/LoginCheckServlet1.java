

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

/**
 * Servlet implementation class LoginCheckServlet1
 */
public class LoginCheckServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCheckServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = null;
		
		String m_username=request.getParameter("username");
		String m_password=request.getParameter("password");
		LoginDao loginDao = new LoginDaoImpl();
		
		String type=loginDao.validate(m_username, m_password);
	//	PrintWriter pw = response.getWriter();
		if(type != null)
		{
			if(type.equals("a"))
			{
				HttpSession session = request.getSession(true);
				session.setAttribute("u_username", m_username);
			   session.setAttribute("u_password", m_password);
			
				url="Adminjsp.jsp";

				
			}
			else if(type.equals("u"))
			{
				HttpSession session = request.getSession(true);
				session.setAttribute("u_username", m_username);
			   session.setAttribute("u_password", m_password);
				url="Customer.jsp";
				
			}
		}
		else
		{
			url ="Books.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);

	}

}
