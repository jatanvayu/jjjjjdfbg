

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;
import com.techm.util.JdbcConnection;

/**
 * Servlet implementation class UpdateProfile
 */
public class UpdateProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String m_fname=request.getParameter("Firstname");
		String m_mname=request.getParameter("Middlename");
		String m_lname=request.getParameter("Lastname");
		String m_building=request.getParameter("building");
		String m_locality=request.getParameter("locality");
		String m_city=request.getParameter("city");
		//int pincode=Integer.parseInt(request.getParameter("pincode"));
		String m_state=request.getParameter("state");
		String m_country=request.getParameter("country");
		String m_email=request.getParameter("email");
		String m_contactno=request.getParameter("contact");
		Connection con=null;
		con=JdbcConnection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String url=null;
		PrintWriter out = response.getWriter();
boolean result = false;
			
			HttpSession session =request.getSession(false);
			String username = (String)session.getAttribute("u_username");
		LoginDao dao = new LoginDaoImpl();
		 result=	dao.update(username, m_fname, m_mname, m_lname, m_building, m_locality, m_city, m_state, m_country, m_email, m_contactno);
			if(result==true)
			{
				url="Adminjsp.jsp";
				out.write("profile updated successfully");
			}
			if(result==false)
			{
				url="Adminjsp.jsp";
				out.print("Profile update failed");
			}
		
		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}

}
