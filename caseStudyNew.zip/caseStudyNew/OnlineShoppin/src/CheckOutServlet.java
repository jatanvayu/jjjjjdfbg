

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;
import com.tech.dao.Product;

/**
 * Servlet implementation class CheckOutServlet
 */
public class CheckOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckOutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session1 = request.getSession(false);
		String product=(String) session1.getAttribute("s_item");
		HttpSession session2 =request.getSession(false);
		String username = (String)session2.getAttribute("u_username");

		LoginDao login = new LoginDaoImpl();
		String payment=request.getParameter("payment");
		String cardDetails= request.getParameter("cardDetails");
		List<Product>alist= login.ShowProduct(product);

		PrintWriter pw = response.getWriter();
		pw.print(product);
		pw.print(username);
		pw.print(payment);
		pw.print(cardDetails);
		
		
		
		login.InsertIntoOrderTable(payment, username, product,cardDetails);
		//login.DeleteFromCart( username,product);
		PrintWriter out = response.getWriter();
		out.print("Order Successfully placed");
	
	}

}
