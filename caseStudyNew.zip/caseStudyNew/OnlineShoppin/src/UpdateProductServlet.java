

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

import com.techm.util.*;

/**
 * Servlet implementation class UpdateProductServlet
 */
public class UpdateProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String panme= request.getParameter("pname");
	   String upname=request.getParameter("upname");
	int uprice=Integer.parseInt(request.getParameter("uprice"));
		PrintWriter out =response.getWriter();
		LoginDao dao = new LoginDaoImpl();
		boolean rec= dao.update1(uprice, panme, upname);
		//out.print(rec);
	/*	if(rec==true)
		{
			String msg = "Product Updated Successfully";
			request.setAttribute("updatemsg",msg );
		}*/
		RequestDispatcher rd = request.getRequestDispatcher("Adminjsp.jsp");
	}

}
