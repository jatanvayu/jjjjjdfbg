

import java.sql.Connection;

import com.techm.util.JdbcConnection;

public class cc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Connection con = null;
con=JdbcConnection.getConnection();

	}

}
