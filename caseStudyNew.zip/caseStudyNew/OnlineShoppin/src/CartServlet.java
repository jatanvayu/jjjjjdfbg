

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

/**
 * Servlet implementation class CartServlet
 */
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String url = null;
		PrintWriter pw = response.getWriter();
	//	response.setContentType("text/html");
		HttpSession session = request.getSession(false);
		String m_username=(String) session.getAttribute("u_username");
		
		if (m_username != null)
		
		{
			String product=request.getParameter("product");
		LoginDao login = new LoginDaoImpl();
		boolean rec=login.InsertIntoCart(product,m_username);
		pw.print(product);
		pw.print(m_username);
		
		
			String msg = "Product added into cart";
			Cookie cookie = new Cookie("message", msg);
			cookie.setMaxAge(-1);
			response.addCookie(cookie);
			pw.println("true");
			//url="Cart.jsp";
			RequestDispatcher rd = request.getRequestDispatcher("Cart.jsp");
			rd.forward(request, response);
			pw.write("updated");
		}
		else
		{
			   // url="Loginjsp.jsp";
				RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
				rd.forward(request, response);
		}
		
	}
	

}
