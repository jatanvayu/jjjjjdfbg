import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.Parameters;


public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 String m_op;
       String url=null;
       String cat =null;
     
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		m_op=request.getParameter("op");
		
		 String u_op=(String)request.getAttribute("catagary");
		//String m_username=null;
		 HttpSession session = request.getSession(false);
	    //m_username=(String) session.getAttribute("u_username");
			
		if(m_op.equals("login"))
		{   
			//if(m_username==null)
			//{
			
				url="Loginjsp.jsp";
			
			
			//}
			//else
				//{
				//url="LoginCheckServlet1";
				//}
			}
		if(m_op.equals("books") || m_op.equals("mobile") || m_op.equals("computer") || m_op.equals("sports")||m_op.equals("clothes")||m_op.equals("home")||m_op.equals("watches"))
		{
			url="Book.jsp";
			request.setAttribute("catagary", m_op);
			HttpSession session1 = request.getSession(true);
			session1.setAttribute("u_catagory", m_op);
			//PrintWriter out = response.getWriter();
			//out.print(m_op);
		}
		if(m_op.equals("LowToHigh") || m_op.equals("HighToLow"))
		{   
			url="BrowseByPrice.jsp";
			
			PrintWriter out = response.getWriter();
			request.setAttribute("Price", m_op);
			String cat1=request.getParameter("op");
			out.print(cat1);
		    String name=(String)request.getAttribute("cat");
		    out.print(name);
			request.setAttribute("cat", cat1);
			out.print("cat1" +cat1);
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(url);
	    rd.forward(request, response);
	}

}
