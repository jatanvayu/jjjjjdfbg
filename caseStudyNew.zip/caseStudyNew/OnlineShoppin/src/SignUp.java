

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.dao.LoginDao;
import com.tech.dao.LoginDaoImpl;

/**
 * Servlet implementation class SignUp
 */
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int contactno= Integer.parseInt(request.getParameter("contact"));
		String Firstname=request.getParameter("Firstname");
		String Middlename=request.getParameter("Middlename");
		String Lastname=request.getParameter("Lastname");
		String building=request.getParameter("building");
		String locality=request.getParameter("locality");
		int pincode= Integer.parseInt(request.getParameter("pincode"));
		String state=request.getParameter("state");
		String city=request.getParameter("city");
		String country=request.getParameter("country");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		PrintWriter pw =response.getWriter();
		
	
		LoginDao dao = new LoginDaoImpl();
		dao.SignUp(Firstname, Middlename, Lastname, building, locality, city, state, pincode, country, email, contactno, password);
		RequestDispatcher rd = request.getRequestDispatcher("Loginjsp.jsp");
		rd.forward(request, response);
	}

}
