package com.tech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import com.techm.util.JdbcConnection;

public class LoginDaoImpl implements LoginDao {
	int rec;

	public String validate(String username, String password)

	{
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		String type = null;
		String url;
		ResultSet rs = null;
		String query = "select type from customer where emailid=? and password=?";

		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2, password);

			rs = pst.executeQuery();

			if (rs.next() == true) {
				type = rs.getString(1);
				return type;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return type;

	}

	public List<Information> updateProfile(String username) {
		// TODO Auto-generated method stub
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		String type = null;
		String url;
		ResultSet rs = null;
		ResultSetMetaData rmd = null;
		System.out.println(username);
		ArrayList<Information> contents = new ArrayList<Information>();
		String query = "select * from customer where emailid=?";
		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			rs = pst.executeQuery();
			rmd = rs.getMetaData();
			int count = rmd.getColumnCount();

			while (rs.next()) {
				String emailid = rs.getString(2);
				String fname = rs.getString(3);
				String mname = rs.getString(4);
				String lname = rs.getString(5);
				String building = rs.getString(6);
				String locality = rs.getString(7);
				String city = rs.getString(8);
				String state = rs.getString(9);
				int pincode = rs.getInt(10);
				String country = rs.getString(11);
				int contactno = (int) rs.getLong(1);
System.out.println(city);
				Information inf = new Information(emailid, fname, mname, lname,
						building, locality, city, state, pincode, country,
						contactno);
				contents.add(inf);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return contents;

	}

	public boolean changePassword(String username, String oldPassword,
			String newPassword, String confirmPassword) {
		// TODO Auto-generated method stub
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		System.out.println(username);
		System.out.println(oldPassword);
		System.out.println(confirmPassword);
		String query = "select password from customer where emailid=?";
		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			rs = pst.executeQuery();
			while (rs.next()) {
				if (oldPassword.equals(rs.getString(1))) {
					if (newPassword.equals(confirmPassword)) {
						pst = conn.prepareStatement("update customer set password=? where emailid=?");
						pst.setString(1, newPassword);
						pst.setString(2, username);
						rec = pst.executeUpdate();
					}
				}
			}
			if (rec == 1) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

		}

		return false;
	}

	public boolean update(String username,String fname,  String mname, String lname, String building, String locality, String city, String state, String country, String emailid, String contactno) {
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		String m_fname=fname;
		String m_mname=mname;
		String m_lname=lname;
		String m_building=building;
		String m_locality=locality;
		String m_city=city;
		
		String m_state=state;
		String m_country=country;
		String m_email=emailid;
		String m_contactno=contactno;
		System.out.println(fname);
		System.out.println(username);
		int result = 0;
			try {
			String	url="update customer set fname=? , mname=?,lname=?,building=?,locality=?,city=?,state=?,country=?,emailid=?,contactno=? where emailid=?";
				ps=con.prepareStatement(url);
				ps.setString(1, m_fname);
				ps.setString(2, m_mname);
				ps.setString(3, m_lname);
				ps.setString(4, m_building);
				ps.setString(5, m_locality);
				ps.setString(6, m_city);
				ps.setString(7, m_state);
				ps.setString(8, m_country);
				ps.setString(9, m_email);
				ps.setString(10, m_contactno);
				ps.setString(11, username);
			result=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		
			if(result==1)
			{
				return true;
			}
		
			else
			{
		
		return false;
			}
	}

	
	public List<Product> search(String catagory) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<Product> contents = new ArrayList<Product>();
		System.out.println(catagory);
		try {
			pst=con.prepareStatement("select * from userproducts where catid=(select catid from cfilter where catname=?)");
			pst.setString(1,catagory);
			rs=pst.executeQuery();
			while(rs.next())
			{
			Product pro = new Product(rs.getString(2), rs.getInt(3), rs.getString(5),rs.getString(6));
			contents.add(pro);
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				rs.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return contents;
	}

	public List<Product> BrowseByPrice(String choice, String catagory ) {
		// TODO Auto-generated method stub
		System.out.println(choice);
		System.out.println(catagory);
		ArrayList<Product> contents = new ArrayList<Product>();
		if(choice.equals("LowToHigh"))
				{
			Connection con =null;
			con=JdbcConnection.getConnection();
			PreparedStatement pst = null;
			ResultSet rs = null;
			
			
				try {
					pst=con.prepareStatement("select * from userproducts where catid=(select catid from cfilter where catname=?)order by price");
					pst.setString(1,catagory);
					rs=pst.executeQuery();
					while(rs.next())
					{
					Product pro = new Product(rs.getString(2), rs.getInt(3),rs.getString(5),rs.getString(6));
					contents.add(pro);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally
				{
					try {
						rs.close();
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				
			}       
		if(choice.equals("HighToLow"))
		{
	Connection con =null;
	con=JdbcConnection.getConnection();
	PreparedStatement pst = null;
	ResultSet rs = null;
	System.out.println("in h2l");
	
		try {
		
			pst=con.prepareStatement("select * from userproducts where catid=(select catid from cfilter where catname=?) order by price desc");
			pst.setString(1,catagory);
			rs=pst.executeQuery();
			while(rs.next())
			{
			Product pro = new Product(rs.getString(2), rs.getInt(3),rs.getString(5),rs.getString(6));
			contents.add(pro);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
			
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}       
		
	return contents;
		
		
}

	public List<Product> ShowProduct(String product) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<Product> contents = new ArrayList<Product>();
		try {
			pst=con.prepareStatement("select * from userproducts where pname=?");
			pst.setString(1,product);
			rs=pst.executeQuery();
			while(rs.next())
			{
			Product pro = new Product(rs.getString(2), rs.getInt(3), rs.getString(5), rs.getString(6));
			contents.add(pro);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				rs.close();
				con.close();
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return contents;
	}

	public boolean InsertIntoCart(String product,String username) {
		// TODO Auto-generated method stub
		Connection con =null;
	con=JdbcConnection.getConnection();
	PreparedStatement pst = null;


		boolean b =false;
		try {
			
			pst=con.prepareStatement("insert into carts values(?,(select pid from userproducts where pname=?))");
			pst.setString(1,username);
			pst.setString(2,product);
			int rec = pst.executeUpdate();
			if(rec==1)
			{
				b= true;
			}
			else
			{
				b=false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return b;
	}

	public List<Product> FetchItems(String username) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs=null;
		String query = "select * from userproducts where pid in(select pid from carts where cid=?)";
		ArrayList<Product> contents = new ArrayList<Product>();
		try {
			pst=con.prepareStatement(query);
			pst.setString(1, username);
			rs=pst.executeQuery();
			while(rs.next())
			{
				String pname=rs.getString(2);
				int price=rs.getInt(3);
				String desc =rs.getString(5);
				String link=rs.getString(6);
		Product pro = new Product(pname, price,desc,link);
			contents.add(pro);
			}
			Iterator<Product> ip = contents.iterator();
			while(ip.hasNext())
			{
				System.out.println(ip.next());
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return contents;
	}

	public boolean DeleteFromCart(String username, String product) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;

      System.out.println(username);
      System.out.println(product);
			boolean b =false;
			try {
				
				pst=con.prepareStatement("delete from carts where cid=? and pid= (select pid from userproducts where pname=?)");
				pst.setString(1,username);
				pst.setString(2,product);
				int rec = pst.executeUpdate();
				System.out.println("fun");
				if(rec>0)
				{
					b= true;
					System.out.println("deleted");
				}
				else
				{ 
					System.out.println("not deleted");
					b=false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return b;
		}

	public List<Product> ShowItems(String product) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs=null;
		String query = "select * from userproducts where pname=?)";
		ArrayList<Product> contents = new ArrayList<Product>();
		try {
			pst=con.prepareStatement(query);
			pst.setString(1, product);
			rs=pst.executeQuery();
			while(rs.next())
			{
			Product pro = new Product(rs.getString(2), rs.getInt(3),rs.getString(5),rs.getString(6));
			contents.add(pro);
			}
			Iterator<Product> ip = contents.iterator();
			while(ip.hasNext())
			{
				System.out.println(ip.next());
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return contents;
	}

	public boolean InsertIntoOrderTable(String pmode,String username,String product, String card) {
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
System.out.println("in func");
		System.out.println(pmode);
		System.out.println(username);
		System.out.println(product);
			boolean b =false;
			try {
		
		
			java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());
			
				
				pst=con.prepareStatement("insert into ordertable values(?,?,1,?,(select max(oid)+1 from ordertable),(select pid from userproducts where pname=?),?)");
				pst.setDate(1, date);
				pst.setString(2,pmode);
				pst.setString(3,username);
				pst.setString(4,product);
				pst.setString(5,card);
			    int rec = pst.executeUpdate();
				if(rec==1)
				{
					b= true;
				}
				else
				{
					b=false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return b;

		
	}

	public boolean MoveToWishlist(String product, String username) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		// TODO Auto-generated method stub
				Connection con1 =null;
				con1=JdbcConnection.getConnection();
				PreparedStatement pst1 = null;
				ResultSet rs1=null;
				String pro=null;
				System.out.println(username);
				System.out.println(product);
			boolean b =false;
			try {
				System.out.println("in try");
				pst1=con1.prepareStatement("select * from userproducts where pname=?");
				pst1.setString(1,product);
				rs1=pst1.executeQuery();
				while(rs1.next())
				{
				 System.out.println("in rs");
				 pro=rs1.getString(1);
				 System.out.println("rs is"+rs1.getString(1));
				}
				 System.out.println(pro);
				pst=con.prepareStatement("insert into wishlist values(?,?)");
				pst.setString(1,username);
				pst.setString(2,pro);
				int rec = pst.executeUpdate();
				System.out.println("fun");
				if(rec>0)
				{
					b= true;
					System.out.println("deleted");
				}
				else
				{ 
					System.out.println("not deleted");
					b=false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return b;
		
	}

	public List<Product> ShowItemsFromWL(String username) {
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs=null;
		System.out.println(username);
		String query = "select * from userproducts where pid in(select pid from wishlist where cid=?)";
		ArrayList<Product> contents = new ArrayList<Product>();
		try {
			pst=con.prepareStatement(query);
			pst.setString(1, username);
			rs=pst.executeQuery();
			while(rs.next())
			{
				String pname=rs.getString(2);
				int price=rs.getInt(3);
				String desc =rs.getString(5);
				String link=rs.getString(6);
			Product pro=new Product(pname,price,desc,link);
			contents.add(pro);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return contents;
	}

	public boolean MoveToCart(String product, String username) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;

      System.out.println(username);
      System.out.println(product);
			boolean b =false;
			try {
				
				pst=con.prepareStatement("insert into carts values(?,(select pid from userproducts where pname=?))");
				pst.setString(1,username);
				pst.setString(2,product);
				int rec = pst.executeUpdate();
			
				if(rec>0)
				{
					b= true;
					System.out.println("deleted");
				}
				else
				{ 
					System.out.println("not deleted");
					b=false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return b;
		
	}

	public boolean DeleteFromWishList(String product, String username) {
		// TODO Auto-generated method stub
			Connection con =null;
			con=JdbcConnection.getConnection();
			PreparedStatement pst = null;

	      System.out.println(username);
	      System.out.println(product);
				boolean b =false;
				try {
					
					pst=con.prepareStatement("delete from wishlist where cid=? and pid= (select pid from userproducts where pname=?)");
					pst.setString(1,username);
					pst.setString(2,product);
					int rec = pst.executeUpdate();
					System.out.println("fun");
					if(rec>0)
					{
						b= true;
						System.out.println("deleted");
					}
					else
					{ 
						System.out.println("not deleted");
						b=false;
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally
				{
					try {
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				return b;
			}

	public boolean InsertProductIntoTable(String pname, int price, String catagory,String file, String des) {
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		System.out.println(pname);
		System.out.println(price);
		System.out.println(catagory);
		String uniqueID = UUID.randomUUID().toString();
		try {
			pst=con.prepareStatement("insert into userproducts (pid,pname,price,catid,ilink,DESCRIPTION)values(?,?,?,(select catid from cfilter where catname=?),? )");
			pst.setString(1,uniqueID);
			pst.setString(2, pname);
			pst.setInt(3, price);
			pst.setString(4, catagory);
			pst.setString(5, file);
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public List<Catagory> FetchCatagory() {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		ArrayList<Catagory> contents = new ArrayList<Catagory>();
		try {
			pst=con.prepareStatement("select catname,catid from catagory");
		
			 rs=pst.executeQuery();
			 while(rs.next())
			 {
			 Catagory cat = new Catagory(rs.getString(2), rs.getString(1));
			 contents.add(cat);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return contents;
	}

	public boolean MoveToWishCart(String product, String username) {
		// TODO Auto-generated method stub
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		// TODO Auto-generated method stub
				Connection con1 =null;
				con1=JdbcConnection.getConnection();
				PreparedStatement pst1 = null;
				ResultSet rs1=null;
				String pro=null;
				System.out.println(username);
				System.out.println(product);
			boolean b =false;
			try {
				System.out.println("in try");
				pst1=con1.prepareStatement("select * from userproducts where pname=?");
				pst1.setString(1,product);
				rs1=pst1.executeQuery();
				while(rs1.next())
				{
				 System.out.println("in rs");
				 pro=rs1.getString(1);
				 System.out.println("rs is"+rs1.getString(1));
				}
				 System.out.println(pro);
				pst=con.prepareStatement("insert into carts values(?,?)");
				pst.setString(1,username);
				pst.setString(2,pro);
				int rec = pst.executeUpdate();
				System.out.println("fun");
				if(rec>0)
				{
					b= true;
					System.out.println("deleted");
				}
				else
				{ 
					System.out.println("not deleted");
					b=false;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return b;
		
	}

public List<OrderDetails> OrderDetails(String sdate, String smonth,String syear,String edate,String emonth,String eyear) {
		Connection con =null;
		con=JdbcConnection.getConnection();
		PreparedStatement pst = null;
		ResultSet rs=null;
	String date1= sdate+"-"+smonth+"-"+syear;
	String date2= edate+"-"+emonth+"-"+eyear;
	System.out.println(date1);
	System.out.println(date2);
		String query = "select odate,oid,pname,price,fname,lname,state,city from ordertable o,userproducts u, customer c where o.pid=u.pid and o.emailid=c.emailid and o.odate between ? and ?";
		ArrayList<OrderDetails> contents = new ArrayList<OrderDetails>();
		try {
			pst=con.prepareStatement(query);
		pst.setString(1, date1);
		pst.setString(2, date2);
			rs=pst.executeQuery();
			while(rs.next())
			{
			OrderDetails od = new OrderDetails(rs.getDate(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(8), rs.getString(7));
			System.out.println(rs.getDate(1));
			contents.add(od);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return contents;
	}

public boolean DeleteFromTable(String product) {
	Connection con =null;
	con=JdbcConnection.getConnection();
	PreparedStatement pst = null;
	PreparedStatement pst1 = null;
 
  System.out.println(product);
		boolean b =false;
		try {
			pst1=con.prepareStatement("delete from ordertable where pid=?");
			pst1.setString(1,product);
			pst1.executeUpdate();
			
			pst=con.prepareStatement("delete from userproducts where pid=?");
		
			pst.setString(1,product);
			int rec = pst.executeUpdate();
			System.out.println("fun");
			if(rec>0)
			{
				b= true;
				System.out.println("deleted");
			}
			else
			{ 
				System.out.println("not deleted");
				b=false;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return b;
	}



public List<Product> FetchFromUserProducts(String pid) {
	Connection con =null;
	con=JdbcConnection.getConnection();
	PreparedStatement pst = null;
	ResultSet rs=null;
	
	String query = "select * from userproducts where pid=?";
	ArrayList<Product> contents = new ArrayList<Product>();
	try {
		pst=con.prepareStatement(query);
		pst.setString(1, pid);
		rs=pst.executeQuery();
		while(rs.next())
		{
		Product pro = new Product(rs.getString(2), rs.getInt(3),rs.getString(5),rs.getString(6));
		contents.add(pro);
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return contents;
}

public boolean update1(int nprice,String pname,String npame) 
{
		// TODO Auto-generated method stub
		Connection con=null;
		con=JdbcConnection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		System.out.println(nprice);
		System.out.println(pname);
		System.out.println(npame);
		
		int result = 0;
			try {
			String	url="update userproducts set pname =?,price=? where pname=?";
				ps=con.prepareStatement(url);
				ps.setString(1, npame);
				ps.setInt(2, nprice);
				ps.setString(3,pname);
			result=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		
			if(result>0)
			{
				return true;
			}
		
			else
			{
		
		return false;
			}
	}

public boolean SignUp(String fname, String mname,
		String lname, String building, String locality, String city,
		String state,int pin, String country, String emailid, int contactno,
		String password) {
     Connection con =null;
     con=JdbcConnection.getConnection();
     PreparedStatement ps =null;
     try {
		ps=con.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?,?,?,?,'u',(select max(cid)+1 from customer),?)");
		ps.setInt(1, contactno);
		ps.setString(2, emailid);
		ps.setString(3, fname);
		ps.setString(4, mname);
		ps.setString(5, lname);
		ps.setString(6, building);
		ps.setString(7, locality);
		ps.setString(8, city);
		ps.setString(9, state);
		ps.setInt(10,pin);
		ps.setString(11, country);
		ps.setString(12, password);
		ps.executeUpdate();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return false;
}

public List<Product> OrderStatus(String username) {
	Connection con =null;
	con=JdbcConnection.getConnection();
	PreparedStatement pst = null;
	ResultSet rs=null;
  String description=null;
  String link=null;
	String query = " select pname,price from userproducts where pid in (select pid from ordertable where emailid=?)";
	ArrayList<Product> contents = new ArrayList<Product>();
	try {
		pst=con.prepareStatement(query);
  pst.setString(1, username);
		rs=pst.executeQuery();
		while(rs.next())
		{
	Product pro = new Product(rs.getString(1), rs.getInt(2), description, link);
		
		contents.add(pro);
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return contents;
}

public boolean InsertIntoOrderTable(String pmode, String username,
		String product, String card, String file) {
	// TODO Auto-generated method stub
	return false;
}





	}

