package com.tech.dao;
import java.sql.ResultSet;
import java.util.List;

public interface LoginDao {
 
	String validate(String username,String password);
	List<Information> updateProfile(String username);
	boolean changePassword(String username, String oldPassword,String newpassword,String confirmPasswor);
	boolean update(String username, String fname,  String mname, String lname, String building, String locality, String city, String state, String country, String emailid, String contactno);
	List<Product> search(String catagory);
	List<Product> BrowseByPrice(String choice, String catagory);
	List<Product> ShowProduct(String product);
	 boolean InsertIntoCart(String product,String username);
	 List<Product> FetchItems(String username);
	 boolean DeleteFromCart(String product,String username);
	 List<Product> ShowItems(String username);
	 boolean InsertIntoOrderTable(String pmode,String username, String product,String card);
	 boolean MoveToWishlist(String product,String username);
	 List<Product> ShowItemsFromWL(String username);
	 boolean MoveToCart(String product,String username);
	 boolean DeleteFromWishList(String product,String username);
	 boolean InsertProductIntoTable(String pname, int price, String catagory,String file,String des);
	 List<Catagory> FetchCatagory();
	 List<OrderDetails> OrderDetails(String sdate, String smonth,String syear,String edatest,String emonth,String eyear);
	 boolean MoveToWishCart(String product,String username);
	 boolean DeleteFromTable(String product);
		boolean update1(int uprice,String pname,String npame);
		 List<Product> FetchFromUserProducts(String pid);
		 boolean SignUp(String fname,  String mname, String lname, String building, String locality, String city, String state,int pin, String country, String emailid, int contactno,String password);
		 List<Product> OrderStatus(String username);
		 
}
