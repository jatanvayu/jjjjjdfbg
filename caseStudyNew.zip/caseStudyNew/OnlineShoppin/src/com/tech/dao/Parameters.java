package com.tech.dao;

public class Parameters {
private String catagory;

public Parameters(String catagory) {
	super();
	this.catagory = catagory;
}
public Parameters() {
	
}
public String getCatagory() {
	return catagory;
}

public void setCatagory(String catagory) {
	this.catagory = catagory;
}

}
