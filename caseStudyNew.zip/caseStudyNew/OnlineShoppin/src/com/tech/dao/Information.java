package com.tech.dao;
public class Information {
private String emailid;
private String fname;
private String mname;
private String lname;
private String building;
private String locality;
private String city;
private String state;
private int pincode;
private String country;
private int contactno;

public Information(String emailid, String fname,String mname, String lname, String building,
		String locality, String city, String state, int pincode,
		String country, int contactno) {
	super();
	this.emailid = emailid;
	this.fname = fname;
	this.mname = mname;
	this.lname = lname;
	this.building = building;
	this.locality = locality;
	this.city = city;
	this.state = state;
	this.pincode = pincode;
	this.country = country;
	this.contactno = contactno;
}

public Information() {
	}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public String getMname() {
	return mname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getBuilding() {
	return building;
}
public void setBuilding(String building) {
	this.building = building;
}
public String getLocality() {
	return locality;
}
public void setLocality(String locality) {
	this.locality = locality;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public int getContactno() {
	return contactno;
}
public void setContactno(int contactno) {
	this.contactno = contactno;
}

}
