package com.tech.dao;

public class Product {
private String pname;
private int price;
private String description;
private String link;
public Product(String pname, int price, String description, String link) {
	super();
	this.pname = pname;
	this.price = price;
	this.description = description;
	this.link = link;
}
public Product() {
	
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getLink() {
	return link;
}
public void setLink(String link) {
	this.link = link;
}

}
