package com.tech.dao;

public class Catagory {
String cid;
String catname;
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public String getCatname() {
	return catname;
}
public void setCatname(String catname) {
	this.catname = catname;
}
public Catagory(String cid, String catname) {
	super();
	this.cid = cid;
	this.catname = catname;
}
public Catagory() {
}
}
