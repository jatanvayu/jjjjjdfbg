package com.tech.dao;

import java.util.Date;

public class OrderDetails {
 private Date odate;



 private String oid;
private String pname;
private int price;
 private String fname;
 private String lname;


 private String city;
 private String state;
public OrderDetails(java.sql.Date odate, String oid, String pname, int price,
		String fname, String lname, String city, String state) {
	super();
	this.odate = odate;
	this.oid = oid;
	this.pname = pname;
	this.price = price;
	this.fname = fname;
	this.lname = lname;
	this.city = city;
	this.state = state;
}
public OrderDetails() {

}
public Date getOdate() {
	return odate;
}
public void setOdate(Date odate) {
	this.odate = odate;
}
public String getOid() {
	return oid;
}
public void setOid(String oid) {
	this.oid = oid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
 
 

}
