package com.techm.util;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


public class UserCounter implements HttpSessionListener {

static int currentcount;
static int totalcount;
    public UserCounter() {
        // TODO Auto-generated constructor stub
    }

    public void sessionCreated(HttpSessionEvent arg0)  { 
         currentcount++;
         totalcount++;
         
         System.out.println("Current Count "+currentcount+"Total Count "+totalcount);
   
    }

    public void sessionDestroyed(HttpSessionEvent arg0)  { 
         currentcount--;
         System.out.println("Current Count "+currentcount);
    }

  public static int getActiveSessions() {
    return currentcount;
  
  }
  public static int getTotal() {
	    return totalcount;
	  }

}