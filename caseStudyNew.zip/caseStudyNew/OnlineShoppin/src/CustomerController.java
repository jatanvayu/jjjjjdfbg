

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerController
 */
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       String m_op,url;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 m_op = request.getParameter("op");
			PrintWriter out = response.getWriter();
			if(m_op.equals("update"))
			{
				url="UpdateProfile.jsp";
			}
			else if(m_op.equals("changePassword"))
			{
				url="ChangePassword.jsp";
			}
			else if(m_op.equals("InsertIntoCart"))
			{
				url="ChangePassword.jsp";
			}
			out.print(m_op);
			RequestDispatcher rd = request.getRequestDispatcher(url);
			rd.forward(request, response);
	}

}
